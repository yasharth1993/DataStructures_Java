
public class ExceptionCls {

	int[] arrayIndx;
	public ExceptionCls(int size) {
		arrayIndx = new int[size];
	}
	public void addElement(int index , int value) {
		arrayIndx[index] = value;
	}
	public static void main(String[] args) {
		

	}

}
