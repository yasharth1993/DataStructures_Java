
public class Clothing {

	private int itemId = 0;
	private String desc = "-description Required-";
	private char colorCode = 'U';
	private double price = 0.00;
	
	
	public Clothing(int itemId , String desc , char colorCode , double price) {
		this.itemId =itemId;
		this.colorCode = colorCode;
		this.desc = desc;
		this.price = price;
	}
	
}
