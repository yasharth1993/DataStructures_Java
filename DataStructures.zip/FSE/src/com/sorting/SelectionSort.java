package com.sorting;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.TreeSet;

public class SelectionSort {

	public static void main(String[] args) {
		int[] a = {20,12,10,15,2};
		int[] b = new int[a.length];
		TreeSet<Integer> ts;
		for(int i=0;i<a.length;i++) {
			ts = new TreeSet<Integer>();
			for(int j=i+1;j<a.length;j++) {
				ts.add(a[j]);
			}
			List<Integer> l = new ArrayList<Integer>( ts );
			for(int k=0;k<ts.size();k++) {
				if(l.get(k)>a[i]) {
					b[i] = l.get(k);
					break;
				}else {
					b[i] = -1;
				}
			}
			if(i==a.length - 1) {
				b[i] = -1;
			}
			
		}
		for(int num : b) {
			System.out.println(num);
		}
	}

}
