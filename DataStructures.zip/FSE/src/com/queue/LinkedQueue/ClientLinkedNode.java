package com.queue.LinkedQueue;

public class ClientLinkedNode {

	public static void main(String[] args) {
		LinkedQueue l = new LinkedQueue();
		l.enQueue(10);
		l.enQueue(15);
		l.enQueue(20);
		l.enQueue(25);
		l.enQueue(30);
		l.enQueue(35);
		l.enQueue(40);
		l.display();
		l.deQueue();
		l.deQueue();
		l.deQueue();
		l.deQueue();
		l.display();

	}

}
