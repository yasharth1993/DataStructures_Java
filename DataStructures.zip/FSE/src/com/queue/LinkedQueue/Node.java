package com.queue.LinkedQueue;

public class Node {
	public int data;
	public Node next;
}
