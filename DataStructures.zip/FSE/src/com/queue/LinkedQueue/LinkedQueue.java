package com.queue.LinkedQueue;

public class LinkedQueue {
	Node head;
	
	public void deQueue() {
		int element;
		if(head == null) {
			System.out.println("Queue is empty!!");
		}else {
			Node tmp = head;
			element = head.data;
			head = head.next;
			System.out.println("Element deleted is :"+element);
		}
	}
	
	public void enQueue(int n) {
		Node node = new Node();
		node.data = n;
		node.next = null;
		if(head == null) {
			head = node;
		}else {
			Node tmp = head;
			while(tmp.next != null) {
				tmp = tmp.next;
			}
			tmp.next = node;
		}
	}
	
	public void display() {
		Node tmp = head;
		while(tmp.next != null) {
			System.out.println(tmp.data);
			tmp = tmp.next;
		}
		System.out.println(tmp.data);
	}
	
}
