package com.queue.Deque;

public class DequeueClient {

	public static void main(String[] args) {
		Dequeue dq = new Dequeue(10);
		dq.insertAtFront(2);
		dq.insertAtFront(3);
		dq.insertAtFront(4);
		dq.insertAtEnd(7);
		dq.insertAtEnd(8);
		//dq.insertAtEnd(6);
		dq.display();
		System.out.println("front is :"+dq.getFront());
		System.out.println("rear is :"+dq.getRear());
		System.out.println("deleted front is :"+dq.deleteAtFront());
		dq.display();
		System.out.println("deleted rear is :"+dq.deleteAtRear());
		System.out.println("deleted rear is :"+dq.deleteAtRear());
		dq.display();
	}

}
