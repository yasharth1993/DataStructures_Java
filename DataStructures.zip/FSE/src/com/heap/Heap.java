package com.heap;

import java.util.ArrayList;

public class Heap {
	
	public static void main(String[] args) {
		ArrayList<Integer> array = new ArrayList<Integer>();
	    int size = array.size();

	    Heap h = new Heap();
	    h.insert(array, 3);
	    h.insert(array, 4);
	    h.insert(array, 9);
	    h.insert(array, 5);
	    h.insert(array, 2);
	    h.insert(array, 7);
	    h.insert(array, 8);
	    h.insert(array, 12);
	    h.insert(array, 13);
	    h.insert(array, 1);
	    h.insert(array, 5);
	    h.insert(array, 8);
	    h.insert(array, 17);
	    
	    h.display(array);
	    System.out.println("Delete top is : "+h.deleteTop(array));
	    System.out.println("Delete top is : "+h.deleteTop(array));
	    System.out.println("Delete top is : "+h.deleteTop(array));
	    System.out.println("Delete top is : "+h.deleteTop(array));
	    System.out.println("Delete top is : "+h.deleteTop(array));
	    System.out.println("Delete top is : "+h.deleteTop(array));
	    System.out.println("Delete top is : "+h.deleteTop(array));
	    System.out.println("Delete top is : "+h.deleteTop(array));
	    h.display(array);
	}

	public void display(ArrayList<Integer> al) {
		for(int i = 0 ; i<al.size();i++ ) {
			System.out.println(al.get(i));
		}
	}
	
	public void insert(ArrayList<Integer> al , int num) {
		int size = al.size();
		if(size == 0) {
			al.add(num);
		}else{
			al.add(num);
			for(int i = size/2 -1 ;i >= 0; i--){
				heapify(al , i);
			}
		}
		
	}
	public void heapify(ArrayList<Integer> al , int i) {
		int size = al.size();
		int largest;
		int l;
		int r;
		largest = i;
		l = 2*i+1;
		r = 2*i+2;
		if(l < size && al.get(largest) < al.get(l)) {
			largest = l;
		}
		if(r < size && al.get(largest) < al.get(r)) {
			largest = r;
		}
		
		if(largest != i) {
			int temp = al.get(largest);
			al.set(largest, al.get(i));
			al.set(i, temp);
			heapify(al , largest);
		}
		
	}
	
	public void deleteElement(ArrayList<Integer> al , int num) {
		int size = al.size();
		int i;
		for(i = 0 ; i < al.size() ; i++ ) {
			if(al.get(i) == num) {
				break;
			}
		}
		al.set(i, al.get(al.size() - 1));
		al.set(al.size() - 1, num);
		al.remove(al.size() - 1);
	}
	
	
	public int deleteTop(ArrayList<Integer> al) {
		int numDel = al.get(0);
		al.remove(0);
		
		for(int i = al.size()/2 -1 ; i>=0 ; i--) {
			heapify(al, i);
		}
		
		return numDel;
	}
	
}
