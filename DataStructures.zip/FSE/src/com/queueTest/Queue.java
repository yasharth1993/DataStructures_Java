package com.queueTest;

public class Queue {
	int front = -1 , rear = -1;
	int[] arr;
	int capacity;
	
	public Queue(int capacity) {
		this.capacity = capacity;
		arr = new int[capacity];
	}
	
	public boolean isFull() {
		if(rear == size() - 1) {
			return true;
		}
		return false;
	}
	
	public int size() {
		return arr.length;
	}
	
	public boolean isEmpty() {
		if(front == -1) {
			return true;
		}
		return false;
	}
	
	public void enQueue(int element) {
		if(isFull()) {
			System.out.println("Queue is full!!");
		}else {
			if(front == -1) {
				front++;
			}
			rear++;
			arr[rear] = element;
		}
	}
	
	public void deQueue() {
		int element;
		if(isEmpty()) {
			System.out.println("Queue is empty!!");
		}else {
			element = arr[front];
			front++;
		}
	}
	
	public void display() {
		for(int i = front ; i<arr.length ; i++) {
			System.out.println(arr[i]);
		}
	}
	
	
}
