package com.queueTest;

public class QueueClient {
	public static void main(String[] args) {
		/*Queue q = new Queue(4);
		q.enQueue(12);
		q.enQueue(13);
		q.enQueue(14);
		q.enQueue(15);
		q.display();
		q.deQueue();
		q.deQueue();
		q.display();*/
		
		CircularQueue cq = new CircularQueue(7);
		cq.enQueue(12);
		cq.enQueue(13);
		cq.enQueue(14);
		cq.enQueue(15);
		cq.enQueue(16);
		cq.enQueue(17);
		cq.enQueue(18);
		cq.deQueue();
		cq.deQueue();
		cq.display();
		cq.enQueue(3);
		cq.enQueue(4);
		cq.display();
		
	}
}
