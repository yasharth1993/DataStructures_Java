package com.queueTest;

public class CircularQueue {

	int front = -1 , rear = -1;
	int capapcity;
	int[] arr;
	
	public CircularQueue(int capacity) {
		this.capapcity = capacity;
		arr = new int[capacity];
	}
	
	public boolean isEmpty() {
		if(front == -1) {
			return true;
		}
		return false;
	}
	
	public int size() {
		return arr.length;
	}
	
	public boolean isFull() {
		if(front == 0 && rear == size() -1) {
			return true;
		}
		if(front == rear+1) {
			return true;
		}
		return false;
	}
	
	public void enQueue(int n) {
		if(isFull()) {
			System.out.println("Queue is full!!");
		}else {
			if(front == -1) {
				front++;
			}
			rear = (rear+1)%size();
			arr[rear] = n;
		}
	}
	
	public int deQueue() {
		int element;
		if(isEmpty()) {
			System.out.println("Queue is empty");
			return -1;
		}else {
			element = arr[front];
			if(front == rear) {
				front = -1;
				rear = -1;
			}else {
				front = (front+1)%size();
			}
			return element;
		}

	}
	
	public void display() {
		int i;
		for(i=front;i!=rear;i=(i+1)%size()) {
			System.out.println(arr[i]);
		}
		System.out.println(arr[i]);
	}
	
	
}
