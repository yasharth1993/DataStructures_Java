package com.graph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;


public class Graph {
	public int numVertices;
	public static ArrayList<ArrayList<Integer>> adjList;
	public static ArrayList<ArrayList<Edge>> adj;

	class Edge{
		public int destination;
		public int weight;
		public Edge(int destination , int weight) {
			this.destination = destination;
			this.weight = weight;
		}
	}
	
	public static void main(String[] args) {
		/*Scanner sc = new Scanner(System.in);
		System.out.println("Enter number of vertices and edges");
		int v = sc.nextInt();
		int e = sc.nextInt();
		Graph g = new Graph(v);*/
		
		
		/*for(int i=0;i<e;i++) {
			int source = sc.nextInt();
			int destination = sc.nextInt();
			g.addEdge(source, destination);
		}
		System.out.println("Enter source and destination");
		int a = sc.nextInt();
		int b = sc.nextInt();
		int n = g.bfs(a, b);
		System.out.println(n);
		System.out.println("Possible :"+g.dfsStack(a, b));*/
		Graph g = new Graph(6);
		/*g.addEdge(0, 4);
		g.addEdge(0, 5);
		g.addEdge(1, 2);
		g.addEdge(1, 4);
		g.addEdge(2, 3);
		g.addEdge(3, 4);
		g.addEdge(3, 5);
		g.addEdge(4, 5);*/
		
		/*g.addDEdge(5, 3);
		g.addDEdge(3, 1);
		g.addDEdge(1, 2);
		g.addDEdge(2, 4);
		g.addDEdge(4, 0);*/
		/*g.addDEdge(1, 0);
		g.addDEdge(2, 0);
		g.addDEdge(3, 0);*/
		//boolean b = g.isCycle(6, adjList);
		//boolean b = g.isCyclicDirected(6, adjList);
		//System.out.println(b);
		//g.topologicalSort(4 ,adjList);
		//int n = g.bfs(1,2);
		//System.out.println(n);
		
		g.addWDEdge(0, 1, 1);
		g.addWDEdge(0, 2, 7);
		g.addWDEdge(1, 2, 5);
		g.addWDEdge(1, 4, 4);
		g.addWDEdge(4, 3, 2);
		g.addWDEdge(2, 3, 6);
		int n = g.minDistDijkshtra(0, 3);
		System.out.println(n);
		
	}
	
	public static boolean dfsUtil(int source  , int destination , boolean vis[]) {
		if(source == destination) {
			return true;
		}
		for(int neighbor : adjList.get(source)) {
			if(!vis[neighbor]) {
				vis[neighbor] = true;
				boolean isConnected = dfsUtil(neighbor , destination , vis);
				if(isConnected) {
					return true;
				}
			}
		}
		
		return false;
	}
	
	public boolean dfsStack(int source  , int destination) {
		boolean[] b = new boolean[numVertices];
		b[source] = true;
		Stack<Integer> s = new Stack<Integer>();
		s.push(source);
		while(s.size() > 0) {
			int current = s.pop();
			if(current == destination) {
				return true;
			}
			for(int neighbor : adjList.get(current)) {
				if(!b[neighbor]) {
					b[neighbor] = true;
					s.push(neighbor);
				}
			}
		}
		return false;
	}
	
	
	public boolean dfs(int source , int destination) {
		boolean[] b = new boolean[numVertices];
		b[source] = true;
		
		return dfsUtil(source, destination, b);
	}
	
	public int bfs(int source , int destination) {
		
		boolean[] vis = new boolean[numVertices];
		int size = 0;
		int dist = 0;
		Queue<Integer> q = new LinkedList<Integer>();
		q.add(source);
		vis[source] = true;
		while(!q.isEmpty()) {
			size = q.size();
			while(size > 0) {
				int num = q.remove();
				for(int neighbor : adjList.get(num)) {
					if(!vis[neighbor]) {
						q.add(neighbor);
						vis[neighbor] = true;
					}
					if(neighbor == destination) {
						dist++;
						return dist;
					}
				}
				size--;
			}
			dist++;
		}
		return dist;
		
		/*boolean[] b = new boolean[numVertices];
		int[] parent = new int[numVertices];
		Queue<Integer> q = new LinkedList<Integer>();
		q.add(source);
		parent[source] = -1;
		b[source] = true;
		while(!q.isEmpty()) {
			int current = q.poll();
			System.out.print(current+" -> ");
			if(current == destination) {
				break;
			}
			for(int neighbor : adjList.get(current)) {
				if(!b[neighbor]) {
					b[neighbor] = true;
					q.add(neighbor);
					parent[neighbor] = current;
				}
			}
		}
		System.out.println();
		int cur = destination;
		int dist = 0;
		while(parent[cur] != -1) {
			System.out.print(cur+" -> ");
			cur = parent[cur];
			dist++;
		}
		
		
		return dist;*/
	}
	
	public Graph(int numVertices) {
		this.numVertices = numVertices;
		adjList = new ArrayList<ArrayList<Integer>>();
		adj = new ArrayList<>();
		for(int i=0;i<numVertices;i++) {
			adjList.add(i, new ArrayList<Integer>());
		}
		
		for(int i=0;i<numVertices;i++) {
			adj.add(i , new ArrayList<Edge>());
		}
	}
	
	public void addEdge(int source , int destination) {
		adjList.get(source).add(destination);
		adjList.get(destination).add(source);
	}
	
	public void addDEdge(int source , int destination) {
		adjList.get(source).add(destination);
		//adjList.get(destination).add(source);
	}
	
	public void addWDEdge(int sourceNode , int destinationNode , int weight) {
		adj.get(sourceNode).add(new Edge(destinationNode, weight));
		//adjList.get(destination).add(source);
	}
	
	boolean fin = false;
	public boolean isCycle(int V, ArrayList<ArrayList<Integer>> adj) {
		boolean[] vis = new boolean[V];
		for(int i=0;i<V;i++) {
			if(!vis[i]) {
				boolean a = dfs(i, -1 , adj , vis);
				if(a) {
					return fin;
				}
			}
		}
		return fin;
	}
	
	public boolean dfs(int current , int parent , ArrayList<ArrayList<Integer>> adj , boolean[] vis) {
		vis[current] = true;
		for(int i: adj.get(current)) {
			if(!vis[i]) {
				dfs(i , current , adj , vis);
			}
			if(i != parent) {
				fin = true;
				return true;
			}
		}
		return false;
	}
	
	
	boolean fins = false;
	public boolean isCyclicDirected(int V , ArrayList<ArrayList<Integer>> adj) {
		boolean[] vis = new boolean[V];
		boolean[] rec = new boolean[V];
		for(int i=0;i<V;i++) {
			if(dfsD(i , adj , vis , rec)) {
				return fins;
			}
		}

		return fins;
	}
	
	public boolean dfsD(int current ,  ArrayList<ArrayList<Integer>> adj , boolean[] vis , boolean[] rec) {
		if(rec[current]) {
			fins = true;
			return true;
		}
		if(vis[current]) {
			return false;
		}
		vis[current] = true;
		rec[current] = true;
		for(int i: adj.get(current)) {
			if(dfsD(i , adj , vis , rec)) {
				fins = true;
			}
		}
		rec[current] = false;
		return false;
	}
	
	public void topologicalSort(int V , ArrayList<ArrayList<Integer>> adj) {
		HashMap<Integer , Integer> hm = new HashMap<Integer , Integer>();
		Queue<Integer> sourceQueue = new LinkedList<Integer>();
		for(int i=0;i<V;i++) {
			hm.put(i, 0);
		}
		
		for(int i=0;i<V;i++) {
			for(int j : adj.get(i)) {
				if(hm.containsKey(j)) {
					hm.put(j, hm.get(j)+1);
				}else {
					hm.put(j, 1);
				}
			}
		}
		for(Map.Entry<Integer, Integer> entry : hm.entrySet()) {
			if(entry.getValue() == 0) {
				sourceQueue.add(entry.getKey());
			}
		}
		
		ArrayList<Integer> al = new ArrayList<Integer>();
		while(!sourceQueue.isEmpty()) {
			int source  = sourceQueue.remove();
			al.add(source);
			for(int child : adj.get(source)) {
				hm.put(child, hm.get(child) - 1);
				if(hm.get(child) == 0) {
					sourceQueue.add(child);
				}
			}
		}
		
		for(int i=0;i<al.size();i++) {
			System.out.print(al.get(i)+" ");
		}
		
	}
	
	
	public int minDistDijkshtra(int source , int destination) {
		int[] distance = new int[numVertices];
		boolean[] vis = new boolean[numVertices];
		for(int i=0;i<numVertices;i++) {
			distance[i] = Integer.MAX_VALUE;
		}
		//PriorityQueue<ArrayList<Integer>> q = new PriorityQueue<ArrayList<Integer>>((al1 , al2) -> al1.get(1) - al2.get(1));
		PriorityQueue<Edge> minHeap = new PriorityQueue<>((e1,e2) -> e1.weight - e2.weight);
		distance[source] = 0;
		minHeap.add(new Edge(source , 0));
		
		while(!minHeap.isEmpty()) {
			int v = minHeap.poll().destination;
			if(vis[v]) {
				continue;
			}
			vis[v] = true;
			for(Edge child : adj.get(v)) {
				int dist = child.weight;
				int childNode = child.destination;
				
				//if(!vis[childNode] && (distance[v] + dist < distance[childNode])) {
				if((distance[v] + dist < distance[childNode])) {
					distance[childNode] = distance[v] + dist;
					//child.weight = distance[v] + dist;
					minHeap.add(child);
				}
			}
		}
		return distance[destination];
		
	}
	
	static int[] dijkstra(int V, ArrayList<ArrayList<ArrayList<Integer>>> adj, int S)
    {
        int[] distance = new int[V];
        boolean[] vis = new boolean[V];
        for(int i=0;i<V;i++){
            distance[i] = Integer.MAX_VALUE;
        }
        PriorityQueue<ArrayList<Integer>> q = new PriorityQueue<ArrayList<Integer>>((al1 , al2) -> al1.get(1) - al2.get(1));
        distance[S] = 0;
        ArrayList<Integer> l = new ArrayList<Integer>();
        l.add(S);
        l.add(0);
        q.add(l);
        
        while(!q.isEmpty()){
            ArrayList<Integer> m = q.poll();
            int v = m.get(0);
            if(vis[m.get(0)]){
                continue;
            }
            
            for(ArrayList<Integer> n : adj.get(v)){
                int dist = (int) n.get(1);
                int destination = (int) n.get(0);
                if(!vis[n.get(0)] && dist + distance[v] < distance[destination]){
                    distance[destination] = dist + distance[v];
                    q.add(n);
                }
                vis[n.get(0)] = true;
            }
        }
        return distance;
        
    }
	
	

}
