package com.graph;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class Edge{
	int src;
	int dest;
	int weight;
	public Edge(int src , int dest, int weight) {
		this.src = src ;
		this.dest = dest;
		this.weight = weight;
	}
	
}

class Graph1 {

	static class Node{
		int value;
		int weight;
		public Node(int value , int weight) {
			this.value = value;
			this.weight = weight;
		}
	}
	
	List<List<Node>> adj_List = new ArrayList<>();
	public Graph1(List<Edge> edges) {
		for(int i=0;i<edges.size();i++) {
			adj_List.add(i , new ArrayList<>());
		}
		for(Edge e : edges) {
			adj_List.get(e.src).add(new Node(e.dest , e.weight));
		}
	}
	
	public static void printGraph(Graph1 graph) {
		int src_vertex = 0;
		int list_size = graph.adj_List.size();
		while(src_vertex < list_size) {
			for(Node n : graph.adj_List.get(src_vertex)) {
				System.out.print("Vertex is :"+src_vertex+" Destination is : "+n.value+" Weight is "+n.weight);
				System.out.println();
			}
			//System.out.println();
			src_vertex++;
		}
	}
	
}

class Main{
	
	public static void main(String[] args) {
		List<Edge> edges = Arrays.asList(new Edge(0, 1, 2),new Edge(0, 2, 4),
                new Edge(1, 2, 4),new Edge(2, 0, 5), new Edge(2, 1, 4),
                new Edge(3, 2, 3), new Edge(4, 5, 1),new Edge(5, 4, 3));
		Graph1 g = new Graph1(edges);
		Graph1.printGraph(g);
	}
}



