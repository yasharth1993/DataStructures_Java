package com.Tree;

public class PerfectBinaryTree {

	
	public static void main(String[] args) {
		 Node root = null;
		    root = new Node(1);
		    root.left = new Node(2);
		    root.right = new Node(3);
		    root.left.left = new Node(4);
		    root.left.right = new Node(5);
		    root.right.left = new Node(6);
		    root.right.right = new Node(6);

		    if (isPerfect(root) == true)
		      System.out.println("The tree is a perfect binary tree");
		    else
		      System.out.println("The tree is not a perfect binary tree");
	}
	//Checking the depth of the tree
	public static int depth(Node node) {
		int d = 0;
		while(node!=null) {
			d++;
			node = node.left;
		}
		return d;
	}
	
	public static boolean isPerfect(Node node , int d , int level) {
		if(node == null) {
			return true;
		}
		if(node.left == null && node.right==null) {
			return (d == level + 1);
		}
		if(node.left == null || node.right == null) {
			return false;
		}
		
		return (isPerfect(node.left , d , level + 1) && isPerfect(node.right , d , level + 1));
	}
	
	//wrapper function 
	public static boolean isPerfect(Node node) {
		int d = depth(node);
		return isPerfect(node , d , 0);
	}
	
}
