package com.Tree;

public class CompleteBinaryTree {

	public static void main(String[] args) {
		 BinaryTree tree = new BinaryTree();

		    tree.root = new Node(1);
		    tree.root.left = new Node(2);
		    tree.root.right = new Node(3);
		    tree.root.left.right = new Node(5);
		    tree.root.left.left = new Node(4);
		    tree.root.right.left = new Node(6);

		    int node_count = countNodes(tree.root);
		    System.out.println("Total nodes are : "+node_count);
		    int level = 0;

		    if (checkComplete(tree.root, level, node_count))
		      System.out.println("The tree is a complete binary tree");
		    else
		      System.out.println("The tree is not a complete binary tree");

	}
	
	static int countNodes(Node node) {
		if(node == null) {
			return 0;
		}
		return (1 + countNodes(node.left) + countNodes(node.right));
	}
	
	
	static boolean checkComplete(Node node, int level , int numberOfNodes) {
		if(node == null) {
			return true;
		}
		if(node.left == null && node.right == null) {
			return true;
		}
		if(node.left != null & node.right == null) {
			return true;
		}
		if(node.left != null && node.right != null) {
			return (checkComplete(node.left , level+1 , 0) && checkComplete(node.right , level + 1 , 0));
		}
		
		return false;
	}

}
