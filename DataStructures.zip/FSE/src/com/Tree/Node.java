package com.Tree;

public class Node {
	public int data;
	public Node left;
	public Node right;
	public int height;
	public Node nextRight;
	
	public Node(int key) {
		  data = key;
		  left = right = null;
	}
}
