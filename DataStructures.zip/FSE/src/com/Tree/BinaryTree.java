package com.Tree;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Queue;
import java.util.TreeMap;

public class BinaryTree {
	static Node root;
	static ArrayList<Integer> al = new ArrayList<>();

	public static void main(String[] args) {
		BinaryTree tree = new BinaryTree();
		  tree.root = new Node(1);
		  tree.root.left = new Node(12);
		  tree.root.right = new Node(9);
		  tree.root.left.left = new Node(5);
		  tree.root.left.right = new Node(6);
		  tree.root.right.left = new Node(8);
		  tree.root.right.right = new Node(10);
		 // tree.inOrder(tree.root);
		 /* System.out.println("******************PreOrder***************");
		  tree.preOrder(tree.root);
		  System.out.println("******************PostOrder***************");
		  tree.postOrder(tree.root);*/
		  /*tree.insert(root, 14);
		  tree.insert(root, 15);
		  System.out.println();
		  tree.inOrder(tree.root);
		  System.out.println();
		  int a = tree.noOfLeaf(root);
		  System.out.println("valus is :"+a);*/
		  //tree.displayLevelOrder(root);
		 /* tree.leftView(root, 0);
		  tree.rightView(root, 0);
		  Collections.reverse(al);
			for(int i=0;i<al.size();i++) {
				System.out.println(al.get(i));
			}*/
		  //tree.topView(root);
		  //tree.findSpiral(root);
		  tree.connect(root);
	}
	
	public BinaryTree() {
		root = null;
	}
	
	public void inOrder(Node node) {	
		
		if(node == null) {
			return;
		}
		inOrder(node.left);
		System.out.print(node.data+" ");
		inOrder(node.right);
	}
	
	public void preOrder(Node node) {	
		
		if(node == null) {
			return;
		}
		System.out.println(node.data);
		preOrder(node.left);
		
		preOrder(node.right);
	}
	
	public void postOrder(Node node) {
		if(node == null) {
			return;
		}
		postOrder(node.left);
		postOrder(node.right);
		System.out.println(node.data);
	}
	public int count= 0 ;
	public int noOfLeaf(Node node) {
		leafUtil(node);
		return count;
	}
	
	public void leafUtil(Node node) {
		if(node == null) {
			return;
		}
		if(node.left == null && node.right == null) {
			count++;
		}
		leafUtil(node.left);
		leafUtil(node.right);
	}
	
	
	
	public void insert(Node temp , int key) {
		TreeMap<Integer,Integer> m = new TreeMap<Integer, Integer>();
		Iterator<Entry<Integer , Integer>> it = m.entrySet().iterator();
		for(Map.Entry<Integer , Integer> entry:m.entrySet()){
			System.out.println(entry.getValue());
		}
		
		if (temp == null) {
            root = new Node(key);
            return;
        }
        Queue<Node> q = new LinkedList<Node>();
        q.add(temp);
 
        // Do level order traversal until we find
        // an empty place.
        while (!q.isEmpty()) {
            temp = q.peek();
            q.remove();
 
            if (temp.left == null) {
                temp.left = new Node(key);
                break;
            }
            else
                q.add(temp.left);
 
            if (temp.right == null) {
                temp.right = new Node(key);
                break;
            }
            else
                q.add(temp.right);
        }
	}
	
	public void displayLevelOrder(Node root) {
		if(root == null) {
			return;
		}
		Queue<Node> q = new LinkedList<Node>();
		q.add(root);
		while(q.size() > 0) {
			Node temp = q.remove();
			System.out.println(temp.data);
			if(temp.right != null) {
				q.add(temp.right);
			}
			if(temp.left != null) {
				q.add(temp.left);
			}
			
		}
		
	}
	int maxLevel = 0;
	public void leftView(Node node , int level) {
		if(node == null) {
			return;
		}
		if(level >= maxLevel) {
			System.out.println(node.data);
			maxLevel++;
		}
		leftView(node.left , level+1);
		leftView(node.right , level+1);
	}
	
	int maxLevelr = 0;
	
	public void rightView(Node node , int level) {
		if(node == null) {
			return;
		}
		if(!(level == 0)) {
			if(level >= maxLevelr ) {
				//al.add(node.data);
				System.out.println(node.data);
				maxLevelr++;
			}
		}
		
		
		rightView(node.right , level+1);
		rightView(node.left , level+1);
	}
	
	
	public void topView(Node root) {
		if(root == null) {
			return;
		}
		Queue<Node> q = new LinkedList<Node>();
		q.add(root);
		TreeMap<Integer , Integer> m = new TreeMap<Integer, Integer>();
		while(!q.isEmpty()) {
			Node temp = q.remove();
			int hd = temp.height;
			/*if(m.get(hd) == null) {
				m.put(hd, temp.data);
			}*/
			m.put(hd, temp.data);
			if(temp.left != null) {
				q.add(temp.left);
				temp.left.height = hd - 1;
			}
			if(temp.right != null) {
				q.add(temp.right);
				temp.right.height = hd + 1;
			}
		}
		for(Entry<Integer , Integer> e : m.entrySet() ) {
			System.out.println(e.getValue());
		}
	
	}
	
	
    ArrayList<Integer> al1 = new ArrayList<Integer>();
    ArrayList<Integer> findSpiral(Node root) 
    {
        //int height = height(root);
        spiralUtil(root , 0 , 0);
        for(int i=0;i<al1.size();i++) {
        	System.out.print(al1.get(i)+" ");
        }
        return al1;
        
    }
    int max = 0;
    public void spiralUtil(Node node , int height , int level){
        
        if(node == null){
            return;
        }
        
        if(level <= max){
        	max++;
            al1.add(node.data);
        }
        if(level%2==0){
            spiralUtil(node.left , height , level+1);
            spiralUtil(node.right , height , level+1);
        }else{
            spiralUtil(node.right , height , level+1);
            spiralUtil(node.left , height , level+1);
        }
        
    }
    
    
    public int height(Node root){
        if(root == null){
            return 0;
        }
        return 1+Math.max(height(root.left) , height(root.right));
    }
	
    public void connect(Node root)
    {
        Node temp = root;
        int height = height(temp);
        for(int i=1;i<=height;i++){
            levelOrder(root , i);
        }
        System.out.println();
        //in-order
        inOrders(root);
    }
    public void inOrders(Node inorder){
        if(inorder == null){
            return;
        }
        inOrders(inorder.left);
        System.out.print(inorder.data+" ");
        inOrders(inorder.right);
    }
    
    public void levelOrder(Node n , int level){
        if(n == null){
            return;
        }
        if(level == 1){
        	System.out.print(n.data+" ");
            n.nextRight = n;
        }
        levelOrder(n.left , level -1);
        levelOrder(n.right , level -1);
    }
    
   
    

}
