package com.linkedlist;

import java.util.AbstractQueue;
import java.util.Collections;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Stack;

import javax.management.Query;

public class Client {

	public static void main(String[] args) {
		PriorityQueue<Integer> p = new PriorityQueue<>(Collections.reverseOrder());
		p.add(2);
		p.add(1);
		p.add(4);
		p.add(3);
		/*System.out.println(p.poll());
		System.out.println(p.poll());*/
		
		Stack<Integer> s = new Stack<>();
		s.add(2);
		s.add(1);
		s.add(4);
		s.add(3);
		s.push(6);
		Queue<Integer> q = new LinkedList<Integer>();
		q.add(1);
		q.add(2);
		System.out.println(q.peek());
		/*LinkedList l = new LinkedList();
		l.insert(0);
		l.insert(1);
		l.insert(2);
		l.insert(0);
		l.insert(1);
		l.insert(2);
		l.insert(1);*/
		//l.insert(8);
		//l.insertAtStart(32);
		//l.insterAt(2, 44);
		//l.delete(2);
		//
		//Node p = l.modify();
		//Node p = l.reverse(3);
		//l.showInput(p);
		//l.middleElement();
		//l.rotate(3);
		//l.reverse(3);
		//int n = l.getNthFromLast(3);
		//System.out.println(n);
		//Node a = l.getHead();
		//Node p = l.flatten(a);
		/*Node a = l.segregate();
		l.show(a);*/
		//l.show();
	}

}

