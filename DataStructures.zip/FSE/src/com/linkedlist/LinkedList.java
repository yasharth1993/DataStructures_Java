package com.linkedlist;

import java.util.ArrayList;
import java.util.Collections;

public class LinkedList {
	Node head;
	Node prevO;
	
	Node segregate()
    {
        Node head1 = null;
        ArrayList<Integer> l = new ArrayList<>();
        Node temp = head;
        while(temp!=null){
            l.add(temp.data);
            temp = temp.next;
        }
        Collections.sort(l);
        for(int i=0;i<l.size();i++){
            Node a = new Node();
            a.data = l.get(i);
            a.next = null;
            if(head1 == null){
                head1 = a;
            }else{
                Node tempo = head1;
                while(tempo!=null){
                    tempo = tempo.next;
                }
                tempo.next = a;
            }
        }
        return head1;
    }
	
	Node getHead() {
		return head;
	}
	
	Node flatten(Node root)
    {
	    ArrayList<Integer> hs = new ArrayList<>();
	    Node head = null;
	    Node temp = root;
	    while(temp != null){
	        Node temp1 = temp;
	        hs.add(temp1.data);
	       /* while(temp1 != null){
	            
	            temp1 = temp1.bottom;
	        }*/
	        temp = temp.next;
	        
	    }
	    Collections.sort(hs);
	    int i = 0;
	    while(i != hs.size()){
	        Node a = new Node();
	        a.data = (int) hs.get(i);
	        //a.next = null;
	        if(head == null){
	           head = a; 
	        }else{
	           Node temp2 = head;
	           while(temp2.next != null){
	               temp2 = temp2.next;
	           }
	           temp2.next = a;
	        }
            i++;
	    }
	    return head;
    }
	
	
	int getNthFromLast(int n)
    {
    	int count = 0;
    	Node temp = head;
    	while(temp !=null){
    	    count++;
    	    temp = temp.next;
    	}
    	if(n > count){
    	    return -1;
    	}
    	Node temp1 = head;
    	for(int i=0;i<n-1;i++){
    	    temp1 = temp1.next;
    	}
    	return temp1.data;
    	
    }
	
	
	
	public Node reverse1(int k) {
		Node temp = head;
		int i=0;
		int len = (length(temp)/k) + 1;
		Node temp1 = head;
		while(i<len) {
			
		}
		return head;
		
	}
	

	
	public Node rotate( int k) {
        for(int i=0;i<k;i++){
            rotateByOne();
        }
        return head;
    }
    
    public void rotateByOne(){
        
        Node n = head;
        head = n.next;
        Node temp = head;
        while(temp.next!=null){
            temp = temp.next;
        }
        temp.next = n;
        temp.next.next = null;
    }
	
	public int middleElement() {
		if(head == null){
            return head.data;
        }
        Node temp = head;
        int count = 0;
        int trav = 0;
        while(temp.next != null){
          temp = temp.next;   
          count++;
        }
        count++;
        if(count%2 == 0){
        trav = count/2 +1;    
        }else{
            trav = count/2;
        }
        Node t = head;
        for(int i=0;i<trav-1;i++){
            t = t.next;
        }
        System.out.println(t.data);
        return t.data;
		
	}
	
	
	public Node reverse(int k) {
		Node temp = head;
		Node head1 = null;
		Node prev = null;
		Node next = null;
		int count = 0;
		int len = length(head);
		while(temp !=null) {

			prev = next;
			System.out.println(temp.data);
			int c = 0;
			while(c!=k && next!=null) {
				next = temp.next;
				temp.next = prev;
				prev = temp;
				temp = next;
				if(count == len) {
					break;
				}
				c++;
			}
			if(head == null) {
				head = prev;
			}
				//
				
			
		//System.out.println("temp "+temp.data);
		//System.out.println("temp next "+temp.next.data);
		//System.out.println("next "+next.data);
		//System.out.println("prev "+prev.data);
		}
		
	
		return prev;
	}
	
	
	public Node modify(){
	       // Node n = new Node();
		   int count = 0;
		   Node nHead = null;
		   int length = length(head);
	       int[] l = new int[length];
	        Node temp = head;
	        while(temp.next != null){
	            l[count] = (temp.data);
	            count++;
	            temp = temp.next;
	        }
	        l[count] = (temp.data);
	        for(int i = 0 ; i < l.length ; i++){
	        	Node n = new Node();
	        	n.next = null;
	        	if(i < l.length/2) {
	        		int val1 = (int) l[i];
		            int val2 = (int) l[(l.length -1 -i)];
		            n.data = val2-val1;
		        	if(nHead == null) {
		        		nHead = n;
		        	}else {
		        		Node temp1 = nHead;
		        		while(temp1.next!=null) {
		        			temp1 = temp1.next;
		        		}
		        		temp1.next = n;
		        	}
	        	}else {
	        		n.data = l[i];
	        		if(nHead == null) {
		        		nHead = n;
		        	}else {
		        		Node temp2 = nHead;
		        		while(temp2.next!=null) {
		        			temp2 = temp2.next;
		        		}
		        		temp2.next = n;
		        	}
	        	}
	        	
	        }
	        return nHead;
	    }
	
	public int length(Node head) {
		int length = 0;
		Node temp = head;
		while(temp.next != null) {
			length++;
			temp = temp.next;
		}
		length++;
		return length;
		
	}
	
	
	public void insert(int data) {
		Node nodeCreate = new Node();
		nodeCreate.data = data;
		nodeCreate.next = null;
		if(head == null) {
			head = nodeCreate;
		}else {
			Node n = head;
			while(n.next != null) {
				n = n.next;
			}
			n.next = nodeCreate;
			
		}
	}
	
	public void delete(int index) {
		Node n = head;
		for(int i=0;i<index-1 ; i++) {
			n = n.next;
		}
		Node nF = n.next;
		n.next = nF.next; 
		System.out.println();
	}
	
	public void insterAt(int index , int data) {
		Node node = new Node();
		node.data = data;
		node.next = null;
		
		Node n = head;
		for(int i = 0 ; i < index - 1 ; i++) {
			n = n.next;
		}
		node.next = n.next;
		n.next = node;
	}
	
	public void insertAtStart(int data) {
		Node node = new Node();
		node.data = data;
		node.next = null;
		node.next = head;
		head = node;
	}
	
	public void showInput(Node node) {
		//Node node = head;
		while(node.next != null) {
			System.out.println(node.data);
			node = node.next;
		}
		System.out.println(node.data);
	}
	
	public void show() {
		Node node = head;
		while(node.next != null) {
			System.out.println(node.data);
			node = node.next;
		}
		System.out.println(node.data);
	}
	
	public void show(Node x) {
		Node node = x;
		while(node.next != null) {
			System.out.println(node.data);
			node = node.next;
		}
		System.out.println(node.data);
	}
	
	
}
