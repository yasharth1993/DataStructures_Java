package com.linkedlist;

public class Node1 {
	int data;
	Node1 next;
	Node1 bottom;
	
	Node1(int d)
	{
		data = d;
		next = null;
		bottom = null;
	}
}
