package com.linkedlist;

public class Node {
	public int data;
	Node next;
}
