package com.stack;

public class Client {

	public static void main(String[] args) {
		Stack st = new Stack();
		st.push(1);
		st.push(2);
		st.push(3);
		st.show();
		st.pop();
	}

}
