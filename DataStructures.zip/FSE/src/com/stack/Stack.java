package com.stack;

public class Stack {
	int arr[] = new int[5];
	int top = 0;
	public void push(int data) {
		arr[top] = data;
		top++;
	}
	
	public void show(){
		for(int i =0 ; i<top ; i++) {
			System.out.println(arr[i]);
		}
	}
	
	public void pop() {
		top--;
		System.out.println(arr[top] + " deleted successfully");
		arr[top] = 0;
		
	}

}
