package com.list.dabal;

public class Client {

	public static void main(String[] args) {
		DoubleLinkedList dl = new DoubleLinkedList();
		System.out.println(dl.isEmpty());
		dl.push(1);
		dl.push(2);
		dl.push(3);
		dl.push(4);
		//dl.get(2);
		dl.show();
		System.out.println();
		System.out.println(dl.size());
		
		dl.delete(3);
		System.out.println();
		dl.show();

	}

}
