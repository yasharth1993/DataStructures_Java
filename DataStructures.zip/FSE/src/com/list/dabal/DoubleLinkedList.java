package com.list.dabal;

import java.util.Iterator;

public class DoubleLinkedList {

	public Node first;
	public Node last;
	
	public DoubleLinkedList() {
		first = null;
		last = null;
	}
	
	public boolean isEmpty() {
		return first == null;	
	}
	
	public int size() {
		Node temp = first;
		int count = 1;
		if(first == last) {
			count=1;
		}
		else {
			while(temp.next!=null) {
				temp = temp.next;
				count++;
			}
		}
		return count;
	}
	
	public void push(int data) {
		Node n = new Node();
		n.data = data;
		n.next = null;
		if(first == null) {
			n.previous = null;
			first = last = n;
		}else {
			n.previous = last;
			last.next = n;
			last = n;
			
		}
	}
	
	public void get(int index) {
		Node temp = first;
		int tempD = 0;
		for(int i = 0; i<index ; i++) {
			temp = temp.next;
			tempD = temp.data;
		}
		System.out.println(tempD);
	}
	
	public void show(){
		Node temp = first;
		while(temp.next != null) {
			System.out.print(temp.data+" ");
			temp = temp.next;
		}
		System.out.print(temp.data+" ");
	}
	
	
	public void delete(int index) {
		int size = size();
		System.out.println();
		if(index == size-1) {
			Node temp = last;
			temp = temp.previous;
			temp.next = null;
		}else {
			Node temp = first;
			for(int i = 0 ; i < index-1 ; i++) {
				temp = temp.next;
				System.out.println(temp.data);
			}
			temp.next.next.previous = temp.next.previous;
			temp.next = temp.next.next;
			System.out.println("Done");
			
		}
		
		
	}
	
}
