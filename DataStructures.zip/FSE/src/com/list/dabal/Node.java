package com.list.dabal;

public class Node {
 public int data;
 public Node previous;
 public Node next;
}
