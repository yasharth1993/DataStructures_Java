package com.codility;

public class FindLCM {

	public static void main(String[] args) {
		int[] A = {2,2,3};
		int div = 2;
		int lcm = 1;
		int count = 0;
		
		while(true){
		boolean divides = false;
		for(int i=0;i<A.length;i++) {	
			if(A[i] == 0) {
				return;
			}
			if(A[i]!=1 && A[i]%div == 0){
				A[i] /= div;
				divides = true;
				if(A[i] == 1) {
					count++;
				}
			}
		}
		if(divides == true) {
			lcm *= div;
		}else {
			div += 1;
		}
		if(count == A.length) {
			System.out.println(lcm);
			break;
		}
		}
		

	}

}
