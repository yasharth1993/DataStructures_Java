package com.codility;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class GivenSum {

	public static void main(String[] args) {
		int[] A = {1,2,4,5,4};
		int B = 6;
		int count = 0;
		/*Map<Integer,Integer> m = new HashMap<Integer,Integer>();
		for(int i=0;i<A.length;i++) {
			count = count + m.getOrDefault(B-A[i], 0);
			if( m.getOrDefault(B-A[i], 0) != 0) {
				System.out.print(A[i]+" "+(B-A[i]));
			}
			m.put(A[i], m.getOrDefault(A[i], 0)+1);
			System.out.println();
		}*/
		System.out.println(count);
		
		HashSet<Integer> hs = new HashSet<Integer>();
		
		for(int i=0;i<A.length;i++) {
			if(hs.contains(B - A[i])) {
				System.out.print(A[i]+" "+(B-A[i]));
				System.out.println();
			}
			hs.add(A[i]);
		}
	}

}
