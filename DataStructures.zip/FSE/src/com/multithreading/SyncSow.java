package com.multithreading;

public class SyncSow {

	public static void main(String[] args) {
		Table t = new Table();
		Thread1 t1 = new Thread1(t);
		Thread2 t2 = new Thread2(t);
		t1.start();
		t2.start();

	}
	
	
	static class Thread1 extends Thread{
		Table t;
		public Thread1(Table t) {
			this.t = t;
		}
		public void run() {
			t.print(2);
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	static class Thread2 extends Thread{
		Table t;
		public Thread2(Table t) {
			this.t = t;
		}
		public void run() {
			t.print(5);
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	
	static class Table{
		public void print(int n) {
			for(int i=1;i<=5;i++) {
				System.out.println("Value is :"+i*n);	
			}
			
		}
	}

}
