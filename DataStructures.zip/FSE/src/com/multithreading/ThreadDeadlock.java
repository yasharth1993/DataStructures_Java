package com.multithreading;

public class ThreadDeadlock {
	static public Object lock1 = new Object();
	static public Object lock2 = new Object();
	public static void main(String[] args) {
		Demo1 d1 = new Demo1();
		Demo2 d2 = new Demo2();
		d1.start();
		d2.start();
		//d1.stop();

	}
	
	
	static class Demo1 extends Thread{
		
		@Override
		public void run() {
			synchronized (lock2) {
				System.out.println("Thread 1 holding lock 1");
				try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				synchronized(lock1) {
					System.out.println("Thread 1 holding lock 2");
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
			}
		}
	}
	
	
	static class Demo2 extends Thread{
		
		@Override
		public void run() {
			synchronized (lock1) {
				System.out.println("Thread 2 holding lock 1");
				try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				synchronized(lock2) {
					System.out.println("Thread 2 holding lock 2");
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
			}
		}
	}
	

}


