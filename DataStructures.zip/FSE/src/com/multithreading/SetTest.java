package com.multithreading;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;

public class SetTest {

	public static void main(String[] args) {
		/*Set<Integer> s = new HashSet<Integer>();
		boolean b = false;
		s.add(1);
		s.add(2);
		s.add(3);
		b = s.add(4);
		System.out.println(b);
		b = s.add(1);
		System.out.println(b);*/
		List<Integer> l  = new ArrayList<Integer>();
		l.add(1);
		l.add(2);
		l.add(3);
		l.add(4);
		l.add(null);
		l.remove(2);
		//System.out.println(l.get(0));
		ListIterator i = l.listIterator();
		while(i.hasNext() && !i.hasPrevious()) {
			System.out.println(i.next());
		}
	}

}
