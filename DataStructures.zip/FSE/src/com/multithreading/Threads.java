package com.multithreading;

public class Threads implements Runnable {
	Thread t1;
	String name;
	
	public Threads(String name) {
		this.name = name;
	}
	public static void main(String[] args) throws InterruptedException {
		Threads th1 = new Threads("Thread-1");
		Threads th2 = new Threads("Thread-2");
		
		Thread ta = new Thread(th1);
		Thread tb = new Thread(th2);
		/*tb.setPriority(10);
		ta.setPriority(1);*/
		
		ta.start();
		tb.start();
		//t1.interrupt();
		//t1.setPriority(10);
		//t1.join();
		
		//t1.join();
	}
	
	public synchronized int print(int n) {
		
			for(int i=0;i<10;i++) {
				System.out.println("value of is "+i*n);
				try {
					Thread.sleep(200);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		
		return 1;
		
		
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		//System.out.println("Inside run"+t1.getName());
		print(10);
		
		
		
	}
	
	/*public void start() {
		t1 = new Thread(this ,name);
		t1.start();
	}*/
	
}
