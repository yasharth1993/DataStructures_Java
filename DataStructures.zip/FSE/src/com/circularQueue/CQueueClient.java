package com.circularQueue;

public class CQueueClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CircularQueue c = new CircularQueue(10);
		//c.isFull();
		c.enqueue(12);
		c.enqueue(13);
		c.enqueue(14);
		c.enqueue(15);
		c.enqueue(16);
		c.enqueue(17);
		c.enqueue(18);
		c.enqueue(19);
		c.enqueue(20);
		c.enqueue(21);
		c.display();
		c.dequeue();
		c.dequeue();
		c.enqueue(22);
		c.enqueue(23);
		c.display();
		

	}

}
