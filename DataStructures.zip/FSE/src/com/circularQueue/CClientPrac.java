package com.circularQueue;

import java.util.LinkedList;

public class CClientPrac {
	public static void main(String[] args) {
		
		CqueuePrac c = new CqueuePrac(5);
		c.enqueue(1);
		c.enqueue(2);
		c.enqueue(3);
		c.enqueue(4);
		c.enqueue(5);
		//c.enqueue(6);
		c.display();
		System.out.println("*****************");
		c.dequeue();
		c.dequeue();
		c.dequeue();
		c.display();
	}
}
