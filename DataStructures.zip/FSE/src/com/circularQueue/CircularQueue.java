package com.circularQueue;


public class CircularQueue {
	int front = -1, rear = -1;
	int capacity = 5;
	int[] arr;
	public CircularQueue(int capacity) {
		this.capacity = capacity;
		arr = new int[capacity];
	}
	public CircularQueue() {
		arr = new int[capacity];
	}
	
	//size of queue
	public int size() {
		return arr.length;
	}
	
	public boolean isFull() {
		//System.out.println("front is :"+front+"rear is :"+rear);
		if(front == 0 && rear == size()-1) {
			System.out.println("one");
			return true;
		}
		if(front == rear +1) {
			System.out.println("two");
			return true;
		}
		
		return false;
	}
	
	public boolean isEmpty() {
		if(front == -1) {
			return true;
		}
		return false;
	}
	
	public void enqueue(int n) {
		if(isFull()) {
			System.out.println("Queue is full");
		}else {
			if(front == -1 ) {
				front++;
			}
			rear = (rear+1)%size();
			arr[rear] = n;
			
		}
	}
	
	public int dequeue() {
		int element = 0;
		if(isEmpty()) {
			System.out.println("Queue is empty");
			return -1;
		}else {
			element = arr[front];
			if(front == rear) {
				front = -1;
				rear = -1;
			}else {
				front = (front + 1) % size();
			}
			return element;
		}
		
	}
	
	public void display() {
		int i;
		for (i = front; i != rear; i = (i + 1) % size())
	        System.out.print(arr[i] + " ");
	      System.out.println(arr[i]);
	}
	
	public static void main(String[] args) {
		int a = 5;
		a = (a+1)%7;
		System.out.println(a);
	}
	
}
