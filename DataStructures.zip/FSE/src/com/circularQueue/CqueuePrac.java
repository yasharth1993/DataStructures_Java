package com.circularQueue;

public class CqueuePrac {
	int front = -1;
	int rear = -1;
	int[] a;
	int capacity;
	public CqueuePrac(int capacity) {
		this.capacity = capacity;
		a = new int[capacity];
	}
	
	public boolean isEmpty() {
		if(front == -1) {
			return true;
		}
		return false;
	}
	
	public boolean isFull() {
		if(front == 0 && rear == capacity -1) {
			return true;
		}
		if(front == rear+1) {
			return true;
		}
		return false;
	}
	
	public void enqueue(int data) {
		if(isFull()) {
			System.out.println("Queue is full");
		}else {
			if(front == -1) {
				front++;
			}
			rear = (rear+1)%capacity;
			a[rear] = data;
		}
	}
	
	public int dequeue() {
		int num = -1;
		if(isEmpty()) {
			System.out.println("Circular queue is empty");
		}else {
			num = a[front];
			if(front == rear) {
				front = -1;
				rear = -1;
			}else {
				front = (front + 1)%capacity;
			}
			
		}
		return num;
	}
	
	
	
	public void display() {
		for(int i=front;i != rear ;i = (i+1)%capacity) {
			System.out.println(a[i]);
		}
	}
	
}
