package com.linked.repeat;

public class Node {
	public int data;
	Node next;
	
}
