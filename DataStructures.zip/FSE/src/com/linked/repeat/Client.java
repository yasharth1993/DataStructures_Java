package com.linked.repeat;

import java.util.HashSet;

public class Client {

	public static void main(String[] args) {
		LinkedList l = new LinkedList();
		l.insert(10);
		l.insert(15);
		l.insert(20);
		l.insertAt(1,34);
		l.delete(1);
		//l.show();
		Node head = l.rotate(2);
		l.showNode(head);
		
		
		HashSet<Integer> hs = new HashSet<>();
		hs.add(1);
	}

}
