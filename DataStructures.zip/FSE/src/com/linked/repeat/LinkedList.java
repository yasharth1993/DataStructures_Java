package com.linked.repeat;

public class LinkedList {

	Node head;
	
	public void insert(int data) {
		Node node = new Node();
		node.data = data;
		node.next = null;
		if(head == null) {
			head = node;
		}
		else {
			Node n = head;
			while(n.next!=null) {
				n = n.next;
			}
			n.next = node;
		}
	}
	
	public void show() {
		Node n = head;
		while(n.next!=null) {
			System.out.println(n.data);
			n=n.next;
		}
		System.out.println(n.data);
	}
	
	public void insertAt(int index , int data) {
		Node n = new Node();
		n.data = data ; 
		n.next = null;
		Node node = head;
		for(int i = 0; i < index -1 ; i++) {
			node = node.next;
		}
		n.next = node.next;
		node.next = n;
	}
	
	public void delete(int index) {
		Node n = head;
		for(int i = 0 ; i< index -1 ; i++) {
			n = n.next;
		}
		Node del = n.next;
		n.next = del.next;
	}
	
	
	Node ret;
    public Node rotate(int k) {
        Node fin = head;
        Node tempo = head;
        for(int i=0;i<k;i++){
            fin = rotateByOneUtil(fin);
        }
        return fin;
    }
    public Node rotateByOneUtil(Node n){
        if(n == null){
            return null;
        }
        Node a = n;
        n = n.next;
        Node temp1 = n;
        
        while(temp1.next != null){
            temp1 = temp1.next;
        }
        temp1.next = a;
        temp1.next.next = null;
        ret = n;
        return ret;
    }
    
    public void showNode(Node n) {
    	Node a = n;
    	while(n.next!=null) {
			System.out.println(n.data);
			n=n.next;
		}
		System.out.println(n.data);
    }
	
	
	
	
}
