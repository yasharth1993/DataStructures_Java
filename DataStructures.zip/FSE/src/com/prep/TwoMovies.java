package com.prep;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.linkedlist.Node;

public class TwoMovies {
public static void main(String[] args) {
	String[] s = {"act","god","cat","dog","tac"};
	List<List<String>> l = TwoMovies.Anagrams(s);
	
	for(List<String> a : l) {
		for(String s1 : a) {
			System.out.print(s1);
		}
	}
	
}

public static List<List<String>> Anagrams(String[] string_list) { 

List<List<String>> l = new ArrayList<List<String>>();
List<String> arr = new ArrayList<String>(Arrays.asList(string_list));
for(int i=0; i<arr.size();i++){
List<String> l1 = new ArrayList<String>();
char[] c = arr.get(i).toCharArray();
Arrays.sort(c);
l1.add(arr.get(i).toString());
for(int j = i+1 ; j< arr.size() ; j++){
    char[] c1 = arr.get(j).toCharArray();
    Arrays.sort(c1);
    if(Arrays.equals(c,c1)){
        l1.add(arr.get(j).toString());
        arr.remove(j);
        j--;
        //string_list[j]="";
        //j--;
    }
}
l.add(l1);
}
return l;
}



public void twoMovies() {

	int[] movDur = {27, 1,10, 39, 12, 52, 32, 67, 76};
	int flight = 77;
	int m1=0;
	int m2 =0;
	for(int i=0 ; i < movDur.length -1 ; i++) {
		for(int j=i+1 ; j < movDur.length ; j++) {
			if(movDur[i] + movDur[j] <= flight) {
				if((m1 + m2) < movDur[i] + movDur[j] ) {
					m1 = movDur[i];
					m2 = movDur[j];
				}else if ((m1 + m2) == movDur[i] + movDur[j]) {
					if(m1 > m2) {
						if(m1 < movDur[i] ) {
							m1 = movDur[i];
							m2 = movDur[j];
						}
					}
					if(m1 < m2) {
						if(m2 < movDur[j]) {
							m1 = movDur[i];
							m2 = movDur[j];
						}
					}
				}
			}
		}
	}
	System.out.println(m1+" "+m2);

}

}