
public class Nag {
	public static void main(String[] args){
		//System.out.println("Yasharth");
		Nag n= new Nag();
		System.out.println(n.Yasharth(8,34));
		//System.out.println(n.subs(10,2));
	}
	
	public int Yasharth(int a, int b) {
		return a + b;
	}
	
	public int subs(int a, int b) {
		return a - b;
	}
	
}
