import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.PriorityQueue;
import java.util.TreeSet;

import com.linkedlist.LinkedList;

public class attempt2 {
static ArrayList<Integer> a = new ArrayList<Integer>();
static int gN = 0;
    
    static List<Integer> pattern(int N){
        a.add(N);
        patternUtil(N-5 , N);
        a.add(N);
        return a;
        // code here
    }
    static void patternUtil(int l, int init){
    	
        if(init == l){
            return;
        }
        a.add(l);
        if(l<0 || gN == 1){
         gN = 1 ;
         patternUtil(l+5 , init);   
        }else if(l > 0){
         patternUtil(l-5 , init);
        }
    
    }
	
	
	String addBinary(String A, String B) {
        StringBuilder sb = new StringBuilder();
        String rem = "";
        if(A.length() > B.length()) {
        	while(A.length() != B.length()) {
        		B= '0'+B;
        	}
        }else{
        	while(A.length() != B.length()) {
        		A = '0'+A;
        	}
        }
        for(int i=A.length()-1;i>=0;i--){
            if(A.charAt(i)=='0' && B.charAt(i)=='0'){
                if(!rem.equals("1")) {
            		sb.append("0");
            	}else {
            		sb.append("1");
            		rem = "0";
            	}
            }
            else if((A.charAt(i)=='1' && B.charAt(i)=='1')){
                if(rem.equals("1")){
                    sb.append("1");
                }else{
                    sb.append("0");
                }
                rem = "1";
            }else{
                if(rem.equals("1")){
                    sb.append("0");
                }else{
                    sb.append("1");
                }
            }
        }
            if(rem.equals("1")){
                sb.append(rem);
            }
            sb.reverse();
            while(sb.charAt(0) == '0') {
            	sb.deleteCharAt(0);
            }
        return sb.toString();
    }
	
	

	public static void main(String[] args) {
		LinkedList l = new LinkedList();
		String s = "1945793875398765938639";
		String s1 = "12345";
		BigInteger b = new BigInteger(s);
		BigInteger b1 = new BigInteger(s1);
		 b = b.add(b1);
		System.out.println(String.valueOf(b));
		
		
		
		/*int[] arr = {5, 9, 6, 2, 9, 6};
		int n = 6;
		int lm = arr[0];
        int rm = arr[n-1];
        int number = 0;
        if(lm>rm){
            System.out.println("-1");
        }
       
        
        int m=0;
        for(int i=1;i<n-1;i++){
        	if(arr[i] >= lm) {
        		lm = arr[i];
        	}
        	if(arr[i] == lm ) {
        		m = i+1;
           	 boolean b = true;
              while(m<=n-1) {
           	   if(arr[i] > arr[m]) {
           		   b = false;
           		   break;
           	   }
           	   m++;
              }
              if(b==true) {
           	   number = arr[i];
           	   break;
              }
        	}
        	
        }
        System.out.println(number);*/
		/*int s = 12;
		boolean b = false;
		ArrayList<Integer> a = new ArrayList<Integer>();
        int sum = 0;
        for(int i=0;i<arr.length;i++){
            int k = i;
            sum = 0;
            while(k>=0){
                if(sum == s){
                    a.add(k);
                    a.add(arr[i]);
                    
                    break;
                }else{
                    sum = sum + arr[k];
                    if(sum == s){
                         a.add(k);
                         a.add(i);
                         b = true;
                         break;
                    }
                    k--;
                }
                if(b == true) {
                	break;
                }
            }
        }*/
		/*pattern(39);
		for(int i=0;i<a.size();i++) {
			System.out.println(a.get(i));
		}
		*/
		 /*String N = "996";
		 //String s = "11";
		 StringBuilder sb = new StringBuilder(N);
	        int l = Integer.parseInt(String.valueOf(N.charAt(N.length() - 1)));
	        int n = l%10;
	        int rem = 0;
	        if(l%10 <=5){
	            sb.deleteCharAt(sb.length()-1);
	            sb.append("0");
	            System.out.println(sb.toString());
	        }else{
	            sb = new StringBuilder();
	            int count = 1;
	            sb.append("0");
	            for(int i=N.length() - 2 ; i>=0;i--){
	                if(Integer.valueOf(String.valueOf(N.charAt(i))) == 9){
	                    //sb.deleteCharAt(i);
	                    sb.append("0");
	                    rem = 1;
	                    count++;
	                    continue;
	                }else{
	                    int num = Integer.valueOf(String.valueOf(N.charAt(i)));
	                    //sb.deleteCharAt(i);
	                    //sb.insert(count , String.valueOf(num + 1));
	                    sb.append(String.valueOf(num + 1));
	                    count++;
	                    rem = 0;
	                    break;
	                }
	            }
	            if(rem != 0) {
	            	sb.append(1);
	            }
	            sb.reverse();
	            N = N.toString().substring(0,N.length() - count)+sb.toString();
	            System.out.println(N);
	            //sb.append(N.toString().substring(0,rem));
	        }*/
	        
		    //return sb.toString();
	        /*StringBuilder sb = new StringBuilder(N);
	        if(Integer.parseInt(String.valueOf(sb.toString().charAt(N.length() - 1))) < 5){
	            sb.insert(N.length() - 1, )
	        }*/
        /*int temp=0;
        int count = 0;
        int res = 0;
        StringBuilder sb = new StringBuilder();
        if(s1.length() < s2.length()){
            while(s1.length() != s2.length()){
               s1="0"+s1; 
            }
        }
        if(s1.length() > s2.length()){
            while(s1.length() != s2.length()){
               s2="0"+s2; 
            }
        }
        for(int i=s1.length()-1;i>=0;i--){
            for(int j=s2.length()-1;j>=0;j--){
                int num1 = Integer.parseInt(String.valueOf(s2.charAt(j)));
                int num2 = Integer.parseInt(String.valueOf(s1.charAt(i)));
                if((num1*num2) + res > 10){
                    sb.append(String.valueOf(Integer.parseInt(String.valueOf(String.valueOf((num1*num2) + res).charAt(1)))));
                    res = Integer.parseInt(String.valueOf(String.valueOf((num1*num2) + res).charAt(0)));
                }else{
                    sb.append(String.valueOf(Integer.parseInt(String.valueOf(String.valueOf((num1*num2) + res).charAt(0)))));
                }
            }
            //sb.append(res);
            temp = (int) (temp + Integer.parseInt(sb.reverse().toString()) * (Math.pow(10, Double.parseDouble(String.valueOf(count)))));
            sb = new StringBuilder();
            res = 0;
            count++;
        }
        System.out.println(String.valueOf(temp));*/
//        return String.valueOf(temp);
        //}
        

		//System.out.println(sb.toString());
		/*String s = "zoomlazapzo";
		String p = "oza";
		StringBuilder temp = new StringBuilder(s);
		StringBuilder sb = new StringBuilder();
		boolean bs = true;
		boolean be = true;
		//System.out.println(sb.deleteCharAt(0).toString());
		//temp = sb;
		while(true) {
			if(bs == true) {
				temp = temp.deleteCharAt(0);
			}if(be == true) {
				temp = temp.deleteCharAt(temp.length()-1);
			}
			for(int i=0;i<p.length();i++) {
				if(temp.toString().contains(String.valueOf(p.charAt(i)))) {
					bs = true;
				}else {
					bs = false;
					//break;
				}
				if(temp.toString().toString().contains(String.valueOf(p.charAt(i)))) {
					be = true;
				}else {
					be = false;
					//break;
				}
				if(bs == false && be == false) {
					break;
				}
				
			}
			if(bs == true && be == true) {
				sb = new StringBuilder(temp);
			}else {
				break;
			}
		}
		
		System.out.println(sb.toString());*/
		
		
		
		
		
		/*String s = "timetopractice";
		String p = "toc";
		StringBuilder sb = new StringBuilder();
        String res = "";
        int start = Integer.MAX_VALUE;
        int sI = 0;
        int eI = 0;
        for(int i=0;i<s.length();i++){
            if(s.charAt(i) == p.charAt(0)){
                sI = i;
            }
            if(s.charAt(i) == p.charAt(p.length() - 1)){
                eI = i;
            }
            if(eI > sI){
                for(int j=0;j<p.length();j++){
                    if(!s.substring(sI , eI+1).contains(String.valueOf(p.charAt(j)))){
                        sI = 0;
                        eI = 0;
                        break;
                    }
                }
                if(res.equals("")){
                    start = eI;
                    res = s.substring(sI , eI+1);
                } 
                if(eI > sI){
                  if(s.substring(sI , eI+1).length() < res.length() ){
                      start = eI;
                      res = s.substring(sI , eI+1);
                  }
                  if(s.substring(sI , eI+1).length() == res.length() ){
                      if(eI < start){
                          start = eI;
                          res = s.substring(sI , eI+1);
                      }
                  }
                }
            }
        }
        System.out.println(res);*/
        //return res;
        
		/*String A = "";
		String B="";
		String s="";
        TreeSet<String> t = new TreeSet<String>();
        for(int i=0;i<A.length();i++){
            if(!B.contains(String.valueOf(A.charAt(i)))){
                s = s+A.charAt(i);
                t.add(String.valueOf(A.charAt(i)));
            }
        }
        for(int i=0;i<B.length();i++){
            if(!A.contains(String.valueOf(B.charAt(i)))){
                s = s+B.charAt(i);
                t.add(String.valueOf(B.charAt(i)));
            }
        }
        while(!t.isEmpty()){
            s = s + t.pollFirst().toString();
        }
        if(s.equals("")){
            s = "-1";
        }*/
        //return s;
		
		/*String s1 = "qufefzniwrhar";
		String s2 = "lzvnmuhlexhec";
		int k = 7;
		boolean b = false;
	      int num = 0;
	      if(s1.length() != s2.length()){
	          //return false;
	    	  b = false;
	      }
	      StringBuilder sb = new StringBuilder(s2);
	      StringBuilder sb1 = new StringBuilder(s1);
	      for(int i=0;i<sb.length();i++){
	          if(sb1.toString().contains(String.valueOf(sb.charAt(i)))){
	        	  int m = sb1.indexOf(String.valueOf(sb.charAt(i)));
	        	  sb1.deleteCharAt(m);
	              sb.deleteCharAt(i);
	              i--;
	          }
	      }
	      //System.out.println("Value is :"+num);
	      if(sb.length() <= k){
	          b = true;
	      }
		System.out.println(b);*/
		/*String s = "i love programming";
		String[] sA = s.split(" ");
		String temp = "";
		String ret="";
		int l = 1;
        for(int i=0;i<sA.length;i++){
        	//System.out.println("Value is :"+sA[i].substring(1, sA[i].length()-1));
        	if(sA[i].length() != 1) {
        		temp = String.valueOf(sA[i].charAt(0)).toUpperCase() + sA[i].substring(1, sA[i].length());
        	}else {
        		temp = String.valueOf(sA[i].charAt(0)).toUpperCase();	
        	}
        	ret = ret + temp;
        	
        }
        String s1 = sA.toString();
        System.out.println(s1);*/
		
		/*int[] a = {98 ,  78, 1, 12, 59, 13,13, 13, 13, 13, 13, 13, 13, 13, 9, 13, 13, 88, 95, 34 };
		//int a[] = {3,1,3,3,2};
		Arrays.sort(a);
		int k=Integer.MIN_VALUE;
		for(int i=0;i<(a.length/2);i++) {
			if(a[i] == a[a.length/2 + i]) {
				k = a[i];
			}
		}
		if(k == Integer.MIN_VALUE) {
			System.out.println(-1);
		}else {
			System.out.println(k);
		}*/
		
		/*ArrayList<Integer> arr = new ArrayList<Integer>();
		arr.add(0);
		ArrayList<Integer> l = new ArrayList<Integer>();
        if(arr.size() < 3){
            //l.add(0);
            System.out.println(l.size());
        }
        int max = Integer.MIN_VALUE;
        int count = 1;
        for(int i=0;i<arr.size();i++){
            if(arr.get(i) > max ){
                max = arr.get(i);
                count++;
            }
        }
        if(count >= 3){
            l.add(1);
        }
        else{
            //l.add(0); 
        }*/
		
		/*int[] a = {98 ,  78, 10, 12, 59, 37, 45, 18, 1, 56, 37, 40, 61, 67, 9, 23, 30, 88, 95, 34 };
		int n = 20;
		int x = 34;
		int y = 56;
		int xi = 0;
        int yi = Integer.MAX_VALUE;
        int min = n;
        int countx = 0;
        int county = 0;
        int b=0;
        for(int i=0;i<n;i++){
            if(a[i]==x){
                countx++;
                xi = i;
            }if(a[i]==y){
                county++;
                yi = i;
            }
            if( min > Math.abs(yi-xi) && (countx > 0 && county > 0)){
                
                min = Math.abs(yi-xi);
                //System.out.print("Hurray! value of min is :"+min);
            }
        }
        if(min == n){
            min = -1;
        }
        if(countx == 0 || county == 0){
            min = -1;
        }    
		System.out.println(min);*/
		/*int[] b = new int[a.length];
		int d=1;
		for(int i=0;i<a.length;i++) {
			if(i+d <= a.length -1) {
				b[i] = a[i+d];
			}else {
				b[i] = a[(i+d) - a.length];
			}
		}
		for(int j=0;j<b.length;j++) {
			System.out.println(b[j]);
		}*/
		
		/*String s = "43112211";
		StringBuilder s1 = new StringBuilder(s);
        //System.out.println("s1 is :"+s1.toString());
		
		String s3 = s1.reverse().toString();
        StringBuilder s2 = new StringBuilder(s3);
        System.out.println("S1 is :"+s1);
        System.out.println("S2 is :"+s2);
		System.out.println(s1.toString().equals(s2.toString()));*/
		
	}
	
	public int retNum(int[] a) {
		if(a.length == 1 ){
            return a[0];
        }
        if(a.length ==2){
            return -1;
        }
        Arrays.sort(a);
		int k=Integer.MIN_VALUE;
		
		for(int i=0;i<a.length/2;i++) {
			if(a[i] == a[a.length/2 + i]) {
				k = a[i];
			}
		}
		if(k == Integer.MIN_VALUE) {
			return -1;
		}else {
			return k;
		}
	}
	
	
	public int internNumber(int input1 , int input2) {
		int pass = 0;
		int initialDaypass = 0;
		int currentdaypass = 0;
		int prevDay = 0;
		int intern = 0;
		
		for(int i=1 ; i<=input1 ; i++) {
			initialDaypass = 5000*i;
			//System.out.println(initialDaypass);
			for(int j=0;j<50 ;j++) {
				if(j==0) {
					currentdaypass = initialDaypass;
				}
				else {
					currentdaypass = prevDay + 5000 + j;
				}
				prevDay = currentdaypass;
				System.out.println(prevDay);
				
				if(currentdaypass == input2) {
					intern = i;
				}
			}
		}
		
		
		return intern;
	}

}
