import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

public class test3 {

	public static void main(String[] args) {
		//String[] Dictionary = {"Hi", "Hello", "HelloWorld", "HiTech", "HiGeek", "HiTechWorld", "HiTechCity", "HiTechLab"};
		String[] Dictionary = {"Hi", "Hello", "HelloWorld", "HiTech", "HiGeek", "HiTechWorld", "HiTechCity", "HiTechLab"};
		String Pattern = "HT";
		int N = 8;
		ArrayList<String> al1 = new ArrayList<>();
        TreeMap<String, ArrayList<String>> hm = new TreeMap<String, ArrayList<String>>();
        for(int i=0;i<N;i++){
            String s = "";
            ArrayList<String> l = new ArrayList<String>();
            for(int j=0;j<Dictionary[i].length();j++){
                if(Dictionary[i].charAt(j) >= 'A' && Dictionary[i].charAt(j) <= 'Z'){
                    s = s+ String.valueOf(Dictionary[i].charAt(j));
                }
            }
            
            if(!hm.containsKey(s)){
            	l.add(Dictionary[i]);
            	hm.put(s, l);
                //hm.put(s , l.add(Dictionary[i]));
            }else{
                ArrayList<String> map = hm.get(s);
                map.add(Dictionary[i]);
                hm.put(s , map);
            }

        }
        boolean b = true;
        for(Entry<String, ArrayList<String>> entry : hm.entrySet()){
            if(entry.getKey().startsWith(Pattern)){
                ArrayList<String> ab = entry.getValue();
                for(int i=0;i<ab.size();i++){
                    al1.add(ab.get(i));
                    System.out.println(ab.get(i));
                }
                
            }
        }
		/*ArrayList<String> al1 = new ArrayList<>();
        TreeMap<String, String> hm = new TreeMap<String, String>();
        for(int i=0;i<N;i++){
            String s = "";
            for(int j=0;j<Dictionary[i].length();j++){
                if(Dictionary[i].charAt(j) >= 'A' && Dictionary[i].charAt(j) <= 'Z'){
                    s = s+ String.valueOf(Dictionary[i].charAt(j));
                }
            }
            hm.put(s , Dictionary[i]);
           

        }
        boolean b = true;
        for(Map.Entry<String,String> entry : hm.entrySet()){
            if(entry.getKey().contains(Pattern)){
                al1.add(entry.getValue());
                System.out.println(entry.getValue());
            }
        }*/
		
		
		//int[] arr = {13, 33, 43, 16, 25, 19, 23, 31, 29, 35, 10, 2, 32, 11, 47, 15, 34, 46, 30, 26, 41, 18, 5, 17, 37, 39, 6, 4, 20, 27, 9, 3, 8, 40, 24, 44, 14, 36, 7, 38, 12, 1, 42, 12, 28, 22, 45};
		//int[] arr = {-47, 1, 4, 49, -18, 10, 26, 18, -11, -38, -24, 36, 44, -11, 45, 20, -16, 28, 17, -49, 47, -48, -33, 42, 2, 6, -49, 30, 36, -9, 15, 39, -6, -31, -10, -21, -19, -33, 47, 21, 31, 25, -41, -23, 17, 6, 47, 3, 36, 15, -44, 33, -31, -26, -22, 21, -18, -21, -47, -31, 20, 18, -42, -35, -10, -1, 46, -27, -32, -5, -4, 1, -29, 5, 29, 38, 14, -22, -9, 0, 43, -50, -16, 14, -26};
		/*int[] arr = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12};
		int size = 13;
		Arrays.sort(arr);
        HashSet<Integer> a = new HashSet<Integer>();
        for(int i=0;i<size;i++){
            if(arr[i] > 0){
                a.add(arr[i]);
            }
        }
        if(a.size() == 1){
            if(a.contains(1)){
                //return 1;
            	System.out.println(1);
            }
        }
        //Collections.sort(a);
        int num = 0;
        boolean b = false;
        
        for(int i=0;i<a.size();i++){
            if(!a.contains(i+1)){
                num = i+1;
                b = true;
                break;
            }
        }
        if(!b){
            num = a.size()+1;
        }
        System.out.println(num);*/
		
		
		
		/*Map<Integer , Integer> m = new HashMap<Integer , Integer>();
        for(int i=0;i<size;i++){
        	int count = 1;
            if(!m.containsKey(arr[i])){
                m.put(arr[i] , count);
            }else {
            	 int temp = m.get(arr[i]);
            	 temp = temp + 1;
            	 m.replace(arr[i], temp);
            	 
            }
        }
        
        int ret = -1;
        //Iterator<Entry<Integer , Integer>> it = m.entrySet().iterator();
        for(Map.Entry<Integer , Integer> me : m.entrySet()){
            int numb = me.getValue();
            if(numb > (size/2)){
                ret = numb;
                break;
            }
        }
        
		//Math.
		int n = 14;
		Arrays.sort(arr);
        ArrayList<Integer> al = new ArrayList<>();
        int[] a = new int[2];
        for(int i=0;i<n;i++){
            if(!al.contains(arr[i])){
                al.add(arr[i]);
            }else{
                a[0] = arr[i];
            }
            
        }
        al.add(0);
       
        for(int i=0;i<n;i++){
        		if(i+1 != Integer.valueOf(al.get(i))){
                    a[1] = i+1;
                    break;
                }
        }
        System.out.println(a[0]+" "+a[1]);*/
	}

}
