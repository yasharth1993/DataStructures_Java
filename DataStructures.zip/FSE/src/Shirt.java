
public class Shirt extends Clothing{

	private char fit = 'U';
	
	public Shirt(int itemId , String desc , char colorCode , double price , char fit) {
		super(itemId , desc , colorCode ,price);
		this.fit = fit;
	}

	public char getFit() {
		return fit;
	}

	public void setFit(char fit) {
		this.fit = fit;
	}
	
}
