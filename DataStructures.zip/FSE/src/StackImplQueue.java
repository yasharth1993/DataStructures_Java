import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Queue;

import com.circularQueue.CircularQueue;

public class StackImplQueue {
	Queue<Integer> q1 = new LinkedList<Integer>();
    Queue<Integer> q2 = new LinkedList<Integer>();
    
    public static void main(String[] args) {
		StackImplQueue s = new StackImplQueue();
		/*s.push(2);
		s.push(3);
		System.out.println(s.pop());
		s.push(4);
		System.out.println(s.pop());*/
    	s.mapF();
	}
    
    void mapF() {
    	HashSet a = new HashSet<>();
    	CircularQueue q3 = new CircularQueue();
    	
    	Map<Integer, Integer> m = new LinkedHashMap<>();
    	m.put(7, 10);
    	m.put(2, 20);
    	m.put(3, 30);
    	Iterator<Entry<Integer, Integer>> e = m.entrySet().iterator();
    	while(e.hasNext()) {
    		Entry<Integer, Integer> es = e.next();
    		System.out.println(es.getKey()+" "+es.getValue());
    	}
    	System.out.println(m.entrySet().iterator().next().getKey());
    }
    
    //Function to push an element into stack using two queues.
    void push(int a)
    {
	    q1.add(a);	
    }
    
    //Function to pop an element from stack using two queues. 
    int pop()
    {
	    if((q1.isEmpty() && q2.isEmpty())){
	        return -1;
	    }
	    if(!q1.isEmpty()){
	        while(q1.size() > 1){
	            q2.add(q1.poll());
	        }
	        return q1.poll();
	    }
	    if(q1.isEmpty() && !q2.isEmpty()){
	        while(q2.size() > 1){
	            q1.add(q2.poll());
	        }
	        return q2.poll();
	    }
	    return -1;
    } 
}
