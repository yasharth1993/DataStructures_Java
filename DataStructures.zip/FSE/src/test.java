
public class test {
	static String a = "doing testing";
	public static String b ;
public static void main(String[] args) {
	//String b;
	/*System.out.println(getSum(2,2,3));
	System.out.println(getSum(2,2,3,4,5));*/
	b=a.toString();
	System.out.println(b);
	
	test t = new test();
	System.out.println(t.b.toString());
	
}

public static int getSum(int... sum){
	int total = 0;
	for(int x : sum) {
	 total += x;	
	}
	
	return total;
	
}


@Override
public String toString() {
	return super.toString()+"kuch bhi";
}
}
