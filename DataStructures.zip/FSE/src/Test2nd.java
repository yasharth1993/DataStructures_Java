import java.math.BigInteger;

public class Test2nd {

	public static void main(String[] args) {
		//int n = largestPrimeFactor(11);
		String[] s = {"-214748364801","-214748364802"};
		String n = secondLargest(s);
System.out.println(n);
	}
	
	public static String secondLargest(String[] input) {
		if(input.length<2) {
			return "-1";
		}

		BigInteger firstMax = new BigInteger(String.valueOf(Long.MIN_VALUE));
		BigInteger secondMax = new BigInteger(String.valueOf(Long.MIN_VALUE));
		BigInteger compare = new BigInteger(String.valueOf(Double.MIN_VALUE));
		for(int i=0;i<input.length;i++) {
			BigInteger num = new BigInteger(input[i]);
			if(num.compareTo(firstMax) == 1) {
				secondMax = firstMax;
				firstMax = num;
			}
			if(num.compareTo(firstMax) == -1 && num.compareTo(secondMax) == 1) {
				secondMax = num;
			}
		}
		if(secondMax.compareTo(compare) == 0) {
			return "-1";
		}
		return secondMax.toString();
	}
	
	
	public static int largestPrimeFactor(long number) {
		int i = 0; 
		//long copyOfInput = number; 
		int longdiv = 0;
		int count = 0 ;
		while(number !=0) {
			long copyOfInput = number; 
			for (i = 2; i <= copyOfInput; i++) 
			{
				if (copyOfInput % i == 0) { 
					copyOfInput /= i; 
					i--; 
				}
			}
			if(copyOfInput % i != 0) {
				number = copyOfInput - 1;
				count++;
			}else {
				number = i;
				count++;
			}
			
			
		}
		
		return count; 
	}

}
